import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserfirstComponent } from './userfirst.component';

describe('UserfirstComponent', () => {
  let component: UserfirstComponent;
  let fixture: ComponentFixture<UserfirstComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserfirstComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserfirstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
