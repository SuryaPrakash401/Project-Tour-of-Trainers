export class User{
    
    username:string;
    firstname:string;
    lastname:string;
    contactnumber:number;
    password:string;
    confirmpassword:string;
}