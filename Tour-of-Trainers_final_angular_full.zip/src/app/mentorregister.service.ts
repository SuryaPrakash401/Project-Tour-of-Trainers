import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MentorregisterService {
  http: any;
  baseUrl: any;
  constructor() { }

  createUser(user:object):Observable<object>{
    return this.http.post('http://localhost:8080/api/mentorservice/save',user);
  }
  
}
