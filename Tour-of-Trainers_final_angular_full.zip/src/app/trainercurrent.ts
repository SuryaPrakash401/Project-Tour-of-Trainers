export class Trainercurrent {
    id: number;
    username: string;
    technology: string;
    completedduration: number;
    pendingduration: number;
}