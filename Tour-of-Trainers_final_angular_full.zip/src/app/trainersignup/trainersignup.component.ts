import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { MentorregisterService } from '../mentorregister.service';
export class Mentor {
  username:string;
  firstname:string;
  lastname:string;
  contactnumber:number;
  
  experience:number;
  facilities:string; 
  
  }

  export class Mentorregister{
    username:string;
    password:string;
    role:Role;
}
export class Role{
  id:number;
  role:string;
}

@Component({
  selector: 'app-trainersignup',
  templateUrl: './trainersignup.component.html',
  styleUrls: ['./trainersignup.component.css']
})
export class TrainersignupComponent implements OnInit {

  mentor: Mentor = new Mentor();
mentorregister:Mentorregister=new Mentorregister();
  submitted = false;
  private error=false;
  username:string;
password:string;
experience:number;
facilities:string
firstname:string;
lastname:string;
contactnumber:number;
role:Role=new Role();
private id=3;
private rolename="mentor";

  constructor(private trainer:ServiceService) { }

  ngOnInit() {
  }

  save() {
    
    this.mentor.username=this.username;
    
    this.mentor.firstname=this.firstname;
    this.mentor.lastname=this.lastname;
    this.mentor.contactnumber=this.contactnumber;
    
    this.mentor.experience=this.experience;
    this.mentor.facilities=this.facilities;
    this.role.id=this.id;
    this.role.role=this.rolename;
    this.mentorregister.role=this.role;
    
    
      this.trainer.createMentor(this.mentor)
        .subscribe(data => console.log(data), error => console.log(error));
      
  
      this.mentorregister.username=this.username;
      this.mentorregister.password=this.password;
      this.trainer.createUserRegister(this.mentorregister)
      .subscribe(data => console.log(data), error => console.log(error));
      this.submitted = true;
      this.error=false
    }
    
}
