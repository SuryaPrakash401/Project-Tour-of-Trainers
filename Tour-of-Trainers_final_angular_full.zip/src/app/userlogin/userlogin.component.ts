import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserregisterService } from '../userregister.service';
import { Userregister } from '../usersignup/usersignup.component';
import { Router } from '@angular/router';


@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  username:string;
  password:string;
  invalidLogin :boolean=false;
   userlogin:Userregister=new Userregister();
   private error=false;
  constructor(private service: UserregisterService,private router:Router) { }

  ngOnInit() {
  }
  validate(){
    
    this.error=false;
    this.service.getUser(this.username).subscribe(value=>this.userlogin=value);
    if(this.userlogin.username==this.username && this.userlogin.password==this.password && this.userlogin.role.id==1){
    
  this.router.navigate(['/usermenu',this.username]);
  this.invalidLogin = false;
    }
    else if(this.userlogin.username==this.username && this.userlogin.password==this.password && this.userlogin.role.id==3){
    
        this.router.navigate(['/trainermenu',this.username]);
        this.invalidLogin = false;
          }
          else  if(this.userlogin.username==this.username && this.userlogin.password==this.password && this.userlogin.role.id==2){
    
            this.router.navigate(['/adminmenu',this.username]);
            this.invalidLogin = false;
              }
          
else{
  this.invalidLogin=true;
}
    }
}
