export class Adminservice{
    duration: number;
    technology:String;
}