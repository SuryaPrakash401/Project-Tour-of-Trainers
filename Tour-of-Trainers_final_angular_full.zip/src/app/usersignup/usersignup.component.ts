import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
export class User {
  username:string;
  firstname:string;
  lastname:string;
  contactnumber:number;
  password:string;
  confirmpassword:string; 
  
  }

  export class Userregister{
    username:string;
    password:string;
    role:Role;
}
export class Role{
  id:number;
  role:string;
}
  

@Component({
  selector: 'app-usersignup',
  templateUrl: './usersignup.component.html',
  styleUrls: ['./usersignup.component.css']
})
export class UsersignupComponent implements OnInit {

  user: User = new User();
userregister:Userregister=new Userregister();
  submitted = false;
  private error=false;
  username:string;
password:string;
confirmpassword:string;

firstname:string;
lastname:string;
contactnumber:number;
role:Role=new Role();
private id=1;
private rolename="user";

  constructor(private trainer:ServiceService) { }

  ngOnInit() {
  }

  

  save() {
    
  this.user.username=this.username;
  
  this.user.firstname=this.firstname;
  this.user.lastname=this.lastname;
  this.user.contactnumber=this.contactnumber;
  this.user.password=this.password;
  this.user.confirmpassword=this.confirmpassword;
  this.role.id=this.id;
  this.role.role=this.rolename;
  this.userregister.role=this.role;
  
  
    this.trainer.createUser(this.user)
      .subscribe(data => console.log(data), error => console.log(error));
    

    this.userregister.username=this.username;
    this.userregister.password=this.password;
    this.trainer.createUserRegister(this.userregister)
    .subscribe(data => console.log(data), error => console.log(error));
    this.submitted = true;
    this.error=false
  }
  }

