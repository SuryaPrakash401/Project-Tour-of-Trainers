import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';

import { AdminmenuComponent } from './adminmenu/adminmenu.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UsermenuComponent } from './usermenu/usermenu.component';

import { TrainermenuComponent } from './trainermenu/trainermenu.component';
import { TrainercurrentComponent } from './trainercurrent/trainercurrent.component';
import { TrainercompletedComponent } from './trainercompleted/trainercompleted.component';
import { UsersearchComponent } from './usersearch/usersearch.component';
import { UsercurrentComponent } from './usercurrent/usercurrent.component';
import { TrainereditComponent } from './traineredit/traineredit.component';
import { UsercompletedComponent } from './usercompleted/usercompleted.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { TrainersignupComponent } from './trainersignup/trainersignup.component';
import { UserfirstComponent } from './userfirst/userfirst.component';
import { ProfileComponent } from './profile/profile.component';
import { LogoutComponent } from './logout/logout.component';

const routes: Routes = [{path:'',component:HomeComponent},{path:'adminlogin',component:AdminloginComponent},
{path:'adminmenu/:username',component:AdminmenuComponent},{path:'userlogin',component:UserloginComponent},
{path:'usermenu/:username',component:UsermenuComponent},{path:'trainerlogin',component:TrainerloginComponent},
{path:'trainermenu/:username',component:TrainermenuComponent},{path:'trainercurrent',component:TrainercurrentComponent},
{path:'trainercompleted',component:TrainercompletedComponent},{path:'usersearch',component:UsersearchComponent},
{path:'usercurrent',component:UsercurrentComponent},{path:'traineredit',component:TrainereditComponent},
{path:'usercompleted',component:UsercompletedComponent},{path:'usersignup',component:UsersignupComponent},
{path:'trainersignup',component:TrainersignupComponent},{path:'userfirst',component:UserfirstComponent},
{path:'profile',component:ProfileComponent},{path:'logout',component:LogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
