import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserregisterService {

  private baseUrl: 'http://localhost:8080/api';
  constructor(private http:HttpClient) { }
  // getUser(username:string):Observable<any>{
  //   return this.http.get(`${this.baseUrl}/User/finduser/${username}`);
  // }
  createUser(user:object):Observable<object>{
    return this.http.post(`${this.baseUrl}/userservice/save`,user);
  }
  getUser(username:string):Observable<any> {  
    return this.http.get(`http://localhost:8080/api/userservice/finduser/${username}`);  
  }
}
