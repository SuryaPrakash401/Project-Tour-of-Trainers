import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-traineredit',
  templateUrl: './traineredit.component.html',
  styleUrls: ['./traineredit.component.css']
})
export class TrainereditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
