export class Mentor{
    
    username:string;
    firstname:string;
    lastname:string;
    contactnumber:number;
    
    experience:number;
    facilities:string;
}