package com.tour.of.trainers.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tour.of.trainers.model.Mentor;
import com.tour.of.trainers.model.MentorCompletedTraining;
import com.tour.of.trainers.model.MentorCurrentTraining;
import com.tour.of.trainers.model.User;
import com.tour.of.trainers.repository.MentorCompletedTrainingRepository;
import com.tour.of.trainers.repository.MentorCurrentTrainingRepository;
import com.tour.of.trainers.repository.MentorRepository;
import com.tour.of.trainers.repository.RoleRepository;
import com.tour.of.trainers.repository.UserRepository;

@Service
public class MentorService {
	@Autowired
	private MentorRepository mentorRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private MentorCompletedTrainingRepository mentorCompletedRepository;
	@Autowired
	private MentorCurrentTrainingRepository mentorCurrentRepository;

	public void saveMentorDetails(Mentor m) {
		mentorRepository.save(m);
		
		
	}
	public void saveMentor(User u) {
		userRepository.save(u);
		
		
	}
	
	
	public List<MentorCompletedTraining> searchCompleted(String username) {
		User u=userRepository.findByUsername(username);
		
		
		return mentorCompletedRepository.findByUsername(u);
		
	}
	public List<MentorCurrentTraining> searchCurrent(String username) {
		User u=userRepository.findByUsername(username);
		
		
		return mentorCurrentRepository.findByUsername(u);
		
	}
	
	
	public Mentor findMentor(String username) {
		return mentorRepository.findByUsername(username);
	}

}