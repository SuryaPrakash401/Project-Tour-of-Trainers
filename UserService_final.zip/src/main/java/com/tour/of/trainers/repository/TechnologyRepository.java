package com.tour.of.trainers.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tour.of.trainers.model.Technology;

@Repository
public interface TechnologyRepository extends CrudRepository<Technology, Integer> {
	List<Technology> findAll();

	Technology findByTechnology(String technology);

}
