export class Usercurrent {
    id: number;
    username: string;
    technology: string;
    completedduration: number;
    pendingduration: number;
}