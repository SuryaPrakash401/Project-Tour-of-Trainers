import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserregisterService {
http: any;
  baseUrl: any;
  constructor() { }
  // getUser(username:string):Observable<any>{
  //   return this.http.get(`${this.baseUrl}/User/finduser/${username}`);
  // }
  createUser(user:object):Observable<object>{
    return this.http.post('http://localhost:8080/api/userservice/save',user);
  }
}
