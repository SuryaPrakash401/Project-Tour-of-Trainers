import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
 
import { UserCurrentService } from '../usercurrent.service';
import { Usercurrent } from '../usercurrent';
@Component({
  selector: 'app-usercurrent',
  templateUrl: './usercurrent.component.html',
  styleUrls: ['./usercurrent.component.css']
})
export class UsercurrentComponent implements OnInit {

  usercurrent: Observable<Usercurrent[]>;
 
  constructor(private userCurrentService: UserCurrentService) { }
 
  ngOnInit() {
    this.reloadData();
  }
 
  // deleteCustomers() {
  //   this.UserCurrentService.deleteAll()
  //     .subscribe(
  //       data => {
  //         console.log(data);
  //         this.reloadData();
  //       },
  //       error => console.log('ERROR: ' + error));
  // }
 
  reloadData() {
    this.usercurrent = this.userCurrentService.getCurrentTraining();
  }

  
}
