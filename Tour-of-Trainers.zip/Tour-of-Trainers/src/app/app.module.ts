import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { AdminmenuComponent } from './adminmenu/adminmenu.component';
import { UsermenuComponent } from './usermenu/usermenu.component';
import { TrainerloginComponent } from './trainerlogin/trainerlogin.component';
import { TrainermenuComponent } from './trainermenu/trainermenu.component';
import { TrainercurrentComponent } from './trainercurrent/trainercurrent.component';
import { TrainercompletedComponent } from './trainercompleted/trainercompleted.component';
import { UsersearchComponent } from './usersearch/usersearch.component';
import { UsercurrentComponent } from './usercurrent/usercurrent.component';
import { TrainereditComponent } from './traineredit/traineredit.component';
import { UsercompletedComponent } from './usercompleted/usercompleted.component';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { TrainersignupComponent } from './trainersignup/trainersignup.component';
import { UserfirstComponent } from './userfirst/userfirst.component';
import { ProfileComponent } from './profile/profile.component';
import { LogoutComponent } from './logout/logout.component';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AdminloginComponent,
    UserloginComponent,
    AdminmenuComponent,
    UsermenuComponent,
    TrainerloginComponent,
    TrainermenuComponent,
    TrainercurrentComponent,
    TrainercompletedComponent,
    UsersearchComponent,
    UsercurrentComponent,
    TrainereditComponent,
    UsercompletedComponent,
    UsersignupComponent,
    TrainersignupComponent,
    UserfirstComponent,
    ProfileComponent,
    LogoutComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
