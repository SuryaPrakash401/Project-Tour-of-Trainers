export class Trainercompleted {
    id: number;
    username: string;
    technology: string;
    duration: number;
}