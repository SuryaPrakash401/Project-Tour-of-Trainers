import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainermenu',
  templateUrl: './trainermenu.component.html',
  styleUrls: ['./trainermenu.component.css']
})
export class TrainermenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
