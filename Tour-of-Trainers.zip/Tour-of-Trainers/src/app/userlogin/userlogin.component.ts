import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserregisterService } from '../userregister.service';


@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
user:User =new User();
submitted=false;

  constructor(private userreg: UserregisterService) { }

  ngOnInit() {
  }
  newUser():void{
    this.submitted=false;
    this.user=new User();
  }
  save(){
    this.userreg.createUser(this.user).subscribe(data => console.log(data),error => console.log(error));
    this.user=new User();
  }
  onSubmit(){
    this.submitted=true;
    this.save();
  }
}
