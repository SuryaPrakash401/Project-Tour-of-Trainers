import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
 
import { TrainerCompletedService } from '../trainercompleted.service';
import { Trainercompleted } from '../trainercompleted';

@Component({
  selector: 'app-trainercompleted',
  templateUrl: './trainercompleted.component.html',
  styleUrls: ['./trainercompleted.component.css']
})
export class TrainercompletedComponent implements OnInit {

  trainercompleted: Observable<Trainercompleted[]>;
 
  constructor(private trainerCompletedService: TrainerCompletedService) { }
 
  ngOnInit() {
    this.reloadData();
  }
 
  // deleteCustomers() {
  //   this.UserCompletedService.deleteAll()
  //     .subscribe(
  //       data => {
  //         console.log(data);
  //         this.reloadData();
  //       },
  //       error => console.log('ERROR: ' + error));
  // }
 
  reloadData() {
    this.trainercompleted = this.trainerCompletedService.getCompletedTraining();
  }

}
