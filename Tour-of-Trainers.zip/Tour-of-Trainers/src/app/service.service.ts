import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  url:string="/assets/data.json";
  
  constructor(private http:HttpClient) { }
  
  getPayment(){
    return this.http.get(this.url);
  }
}

