import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
 
import { UserCompletedService } from '../usercompleted.service';
import { Usercompleted } from '../usercompleted';

@Component({
  selector: 'app-usercompleted',
  templateUrl: './usercompleted.component.html',
  styleUrls: ['./usercompleted.component.css']
})
export class UsercompletedComponent implements OnInit {

  usercompleted: Observable<Usercompleted[]>;
 
  constructor(private userCompletedService: UserCompletedService) { }
 
  ngOnInit() {
    this.reloadData();
  }
 
  // deleteCustomers() {
  //   this.UserCompletedService.deleteAll()
  //     .subscribe(
  //       data => {
  //         console.log(data);
  //         this.reloadData();
  //       },
  //       error => console.log('ERROR: ' + error));
  // }
 
  reloadData() {
    this.usercompleted = this.userCompletedService.getCompletedTraining();
  }

}
