import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {



  private baseUrl = 'http:localhost://8080/api';
  constructor(private http:HttpClient) { }

getPayment(){
  return this.http.get(`${this.baseUrl}/adminservice/findpayment`);
}
getTechnology():Observable<any>{
  return this.http.get(`${this.baseUrl}/adminservice/findadmintechnology`);
}
getUser(){
  return this.http.get(`${this.baseUrl}/adminservice/finduser`);
}
getMentor(){
  return this.http.get(`${this.baseUrl}/adminservice/findmentor`);
}
userblock(username:string){
  return this.http.get(`${this.baseUrl}/adminservice/userblock/${username}`);
}
userunblock(username:string){
  return this.http.get(`${this.baseUrl}/adminservice/userunblock/${username}`);
}
addTechnology(technology:string,duration:string){
  return this.http.get(`${this.baseUrl}/adminservice/savetechnology/${technology}/${duration}`);
}
}
