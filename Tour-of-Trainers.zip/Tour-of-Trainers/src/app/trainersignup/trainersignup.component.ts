import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainersignup',
  templateUrl: './trainersignup.component.html',
  styleUrls: ['./trainersignup.component.css']
})
export class TrainersignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
