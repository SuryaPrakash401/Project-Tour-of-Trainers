package com.tour.of.trainers.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.tour.of.trainers.model.Mentor;
import com.tour.of.trainers.model.MentorCompletedTraining;
import com.tour.of.trainers.model.MentorCurrentTraining;
import com.tour.of.trainers.service.MentorService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@Controller
public class MainController {
	@Autowired
	private MentorService mentorService;

	@PostMapping("/save")
	public @ResponseBody String saveUser(@RequestBody Mentor m) {
		mentorService.saveMentorDetails(m);
		return "stored";
	}

	@GetMapping(path = "/saveuser/{username}/{password}")
	public @ResponseBody String user(@PathVariable String username, @PathVariable String password) {

		mentorService.saveUser(username, password);
		return "saved";
	}

	@GetMapping("mentorcompleted/findcompleted")
	public @ResponseBody List<MentorCompletedTraining> findcompleted() {

		return mentorService.searchCompleted();
	}

	@GetMapping("mentorcurrent/findcurrent")
	public @ResponseBody List<MentorCurrentTraining> findcurrent() {

		return mentorService.searchCurrent();
	}

}