package com.tour.of.trainers.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tour.of.trainers.model.User;
import com.tour.of.trainers.model.UserCompletedTraining;

@Repository
public interface UserCompletedRepository extends CrudRepository<UserCompletedTraining, Integer> {

	public List<UserCompletedTraining> findByUsername(User u);
}
