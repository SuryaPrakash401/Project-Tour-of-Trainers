package com.tour.of.trainers.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tour.of.trainers.model.User;
import com.tour.of.trainers.model.UserCurrentTraining;

@Repository
public interface UserCurrentRepository extends CrudRepository<UserCurrentTraining, Integer> {

	List<UserCurrentTraining> findByUsername(User u);

}