import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
 
import { TrainerCurrentService } from '../trainercurrent.service';
import { Trainercurrent } from '../trainercurrent';

@Component({
  selector: 'app-trainercurrent',
  templateUrl: './trainercurrent.component.html',
  styleUrls: ['./trainercurrent.component.css']
})
export class TrainercurrentComponent implements OnInit {

  trainercurrent: Observable<Trainercurrent[]>;
 
  constructor(private trainerCurrentService: TrainerCurrentService) { }
 
  ngOnInit() {
    this.reloadData();
  }
 
  // deleteCustomers() {
  //   this.UserCurrentService.deleteAll()
  //     .subscribe(
  //       data => {
  //         console.log(data);
  //         this.reloadData();
  //       },
  //       error => console.log('ERROR: ' + error));
  // }
 
  reloadData() {
    this.trainercurrent = this.trainerCurrentService.getCurrentTraining();
  }


}
