import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  url:string="/assets/data.json";
  private baseUrl = 'http://localhost:8080/api'; 
  
  constructor(private http:HttpClient) { }
  
  getPayment(){
    return this.http.get(this.url);
  }
  createUser(user: object): Observable<object> {  
    return this.http.post(`${this.baseUrl}/userservice/save`, user);  
  } 
  createUserRegister(userregister:object):Observable<object>{
    return this.http.post(`${this.baseUrl}/userservice/user`, userregister);
  }
  createMentor(user: object): Observable<object> {  
    return this.http.post(`${this.baseUrl}/mentorservice/save`, user);  
  } 

  getUser(username:string):Observable<any> {  
    return this.http.get(`${this.baseUrl}/userservice/finduser/${username}`);  
  }

}

