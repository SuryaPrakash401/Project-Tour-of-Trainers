import { TestBed } from '@angular/core/testing';

import { MentorregisterService } from './mentorregister.service';

describe('MentorregisterService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MentorregisterService = TestBed.get(MentorregisterService);
    expect(service).toBeTruthy();
  });
});
