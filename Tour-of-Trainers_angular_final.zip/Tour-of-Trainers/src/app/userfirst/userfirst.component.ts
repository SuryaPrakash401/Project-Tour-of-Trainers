import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userfirst',
  templateUrl: './userfirst.component.html',
  styleUrls: ['./userfirst.component.css']
})
export class UserfirstComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
