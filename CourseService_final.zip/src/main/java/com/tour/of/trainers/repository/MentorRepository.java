package com.tour.of.trainers.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tour.of.trainers.model.Mentor;

@Repository
public interface MentorRepository extends CrudRepository<Mentor, Integer> {

	Mentor findByUsername(String username);

}
