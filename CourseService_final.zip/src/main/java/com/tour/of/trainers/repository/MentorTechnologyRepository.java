package com.tour.of.trainers.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tour.of.trainers.model.Mentor;
import com.tour.of.trainers.model.MentorTechnology;

@Repository

public interface MentorTechnologyRepository extends CrudRepository<MentorTechnology, Integer> {

	List<MentorTechnology> findByTechnology(String technology);

	MentorTechnology findByMentorname(Mentor mentorname);

}
