package com.tour.of.trainers.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tour.of.trainers.model.Technology;

@Repository
public interface TechnologyRepository extends CrudRepository<Technology, Integer> {

}